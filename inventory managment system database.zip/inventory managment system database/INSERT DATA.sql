-- insert records into user table
insert into users (ID,FullNAME, contact, E_MAIL, PASSWORD) values
('1','ABDULMANAN', '03174689617', 'manan@gmail.com', '12345678'),
('2','IQRA', '03097002398', 'igra@gamil.com', '87654321'),
('3','ZAIN', '03074629463', 'zain@gamil.com', '11223344'),
('4','ROSHANY', '03254279445', 'amna@gamil.com', '55667788'),
('5','ZAIN', '03074629463', 'zain1@gamil.com', '11223344'), 
('6','ROSHANY', '03254279445', 'amna1@gamil.com', '55667788')


--insert records into customer table
insert into customer (ID,FirstNAME, LastNAME, contact, E_MAIL, PASSWORD, CUSTOMER_STATUS, CUSTOMER_ADDRESS) values
('1','ali', 'raza', '123', 'qwe@gamil.com', '12', 'yes', 'lahore'),
('2','ahmad', 'muhsin', '456', 'aa@gamil.com', '13', 'yes', 'karachi'), 
('3','waqas', 'younus', '789', 'bb@gamil.com', '14', 'yes', 'lahore'),
('4','ahad', 'shafeeq', '134', 'www@gamil.com', '15', 'yes', 'sind'),
('5','ahsaan', 'saleem', '222', 'dd@gamil.com', '16', 'no', 'islamabad'), 
('6','hassan', 'nazir', '333', 'ss@gamil.com', '17', 'yes', 'sind'),
('7','sufyan', 'nazir', '321', 'pp@gamil.com', '18', 'yes', 'karachi'),
('8','mahanoor', 'akram', '532', 'oo@gamil.com', '19', 'no', 'lahore'),
('9','sami', 'suleman', '45657', 'hh@gamil.com', '10', 'no', 'sind'),
('10','farhan', 'zahid', '09988', 'gg@gamil.com', '21', 'yes', 'karachi'),
('11','suleman', 'abdulmanan', '56778', 'uu@gamil.com', '22', 'yes', 'islamabad'),
('12','alishba', 'tahir', '4678', 'qq@gamil.com', '23', 'yes', 'lahore'), 
('13','aliza', 'hussan', '68585', 'ee@gamil.com', '24', 'yes', 'karachi'),
('14','ayna', 'khalid', '12355', 'rr@gamil.com', '25', 'yes', 'sind'), 
('15','mubara', 'azam', '09876', 'tt@gamil.com', '26', 'yes', 'islamabad'), 
('16','kainat', 'butt', '57357.3', 'yy@gamil.com', '27', 'no', 'lahore'), 
('17','sajela', 'butt', '86885', 'jj@gamil.com', '28', 'no', 'sind'), 
('18','aleesha', 'amjad', '8768689', 'mm@gamil.com', '29', 'no', 'karachi'),
('19','afagh', 'tahir', '8786655', 'nn@gamil.com', '30', 'yes', 'lahore'), 
('20','noor', 'amjad', '5757', 'cc@gamil.com', '33', 'yes', 'islamabad'), 
('21','maham' ,'naim', '121212', '11@gamil.com', '34', 'yes', 'lahore')



insert into menutype(ID, TYPES_NAME)values
('3','CHANUS'),
('2','DESI'),
('5','JUICE'),
('1','JUNK_FOOD'),
('4','SHAKE')



INSERT INTO menu (ID,ITEM_NAME, ITEM_STATUS, PRICE, MENU_TYPE) VALUES
('1','BIYANI', 'yes', '350', '2'),
('2','PAKORA', 'yes', '120', '2'),
('3','PAROTHA', 'yes', '70', '2'),
('4','PIZZA', 'yes', '1100', '1'),
('5','DAAL_CHAWAL', 'no', '150', '2'),
('6','BURGER', 'yes', '320', '1'),
('7','CHIPS', 'yes', '180', '1'),
('8','NAGETS', 'no', '450', '1'),
('9','FRIED RICE', 'no', '440', '3'),
('10','CROW_MEIN', 'yes', '800', '3'),
('11','PEKING_DUCK', 'yes', '320', '3'),
('12','STINKY_TOFU', 'no', '550', '3'),
('13','APPLE', 'yes', '150', '4'), 
('14','BANANA', 'yes', '150', '4'),
('15','ORIO', 'yes', '150', '4'),
('16','MANGO', 'yes', '150', '4'),
('17','ORANGE', 'yes', '120', '5'),
('18','FALSA', 'yes', '120', '5'),
('19','KALE', 'yes', '120', '5'), 
('20','BEETS', 'no', '120', '5')


INSERT INTO deal_of_the_day( DEAL_ID, DEAL_NAME, DEAL_STATUS, PRICE,MENU_TYPE) VALUES
('91','WEEKEND box','YES','2950','2'),
('92','chinese box','YES','1999','3'),
('93','SPICY PAKISTANI FOOD','NO','1499','1'),
('94','5 PERSON SHAKE','YES','499','4')


-- now enter date into orders table
INSERT INTO orders (ID,CUSTOMER_ID, USERS_ID, ORDER_STATUS, AMOUNT, ORDER_DATE)
VALUES
('1','21','9','DONE','1000','2023-06-10'),
('2','22','10','NO','2020','2023-06-11'),
('3','23','11','DONE','1150','2023-06-12'),
('4','24','12','NO','1200','2023-06-13'),
('5','25','13','DONE','1800','2023-06-14'),
('6','26','14','NO','9050','2023-06-15'),
('7','27','15','DONE','3050','2023-06-16'),
('8','28','16','NO','250','2023-06-17'),
('9','29','17','DONE','1770','2023-06-18'),
('10','30','18','NO','1340','2023-06-19'),
('11','31','19','DONE','2320','2023-06-20'),
('12','32','20','NO','1950','2023-06-21'),
('13','33','21','DONE','1310','2023-06-22'),
('14','34','22','NO','1680','2023-06-23'),
('15','35','23','DONE','2780','2023-06-24'),
('16','36','24','NO','2309','2023-06-26'),
('17','37','25','DONE','1010','2023-06-27'),
('18','38','26','NO','1300','2023-06-28'),
('19','39','27','DONE','2950','2023-06-29'),
('20','40','28','NO','2190','2023-06-30')


INSERT INTO orderdetail (ID, MENU_ID, ORDER_ID, QUANTITY, TOTAL_AMOUNT) VALUES
('1','1',' 21',' 2',' 1050'),
('2','2', '23', '3', '1350'),
('3','3',' 22',' 1', '800'),
('4','8',' 31',' 4',' 2000'),
('5','3',' 33', '2', '1270'),
('6','13',' 40',' 3', '15560'),
('7','12',' 25',' 2',' 902'),
('8','12',' 35', '1', '740'),
('9','9',' 26', '2', '1210'),
('10','19',' 27',' 3', '1480'),
('11','20', '30', '2', '1330'),
('12','1',' 21', '2',' 1050'),
('13','2,',' 23',' 3',' 1350'),
('14','3',' 22', '1',' 800'),
('15','8',' 31',' 4',' 2000'),
('16','3',' 33',' 2',' 1270'),
('17','13',' 40',' 3', '15560'),
('18','12', '25',' 2',' 902'),
('19','12', '35',' 1',' 740'),
('20','19',' 27',' 3',' 1480'),
('21','15', '37', '4',' 2220')



INSERT INTO payment (ID, ORDER_ID, USERS_ID,PAYMENT_METHOD, PAYMENT_DATE) values
('1','22', '5', 'easypesa', '2023-06-10'),
('2','23',' 6', 'jazzcash', '2023-06-11'),
('3','36',' 7', 'easypesa', '2023-06-12'),
('4','32',' 8', 'Bank HBL', '2023-06-13'),
('5','33',' 5', 'jazzcash', '2023-06-14'),
('6','34', '6', 'Meezan Bank', '2023-06-15'),
('7','25',' 7', 'Bank HBL', '2023-06-16'),
('8','26',' 8', 'easypesa', '2023-06-17'),
('9','27',' 5', 'Meezan Bank', '2023-06-18'),
('10','38',' 6', 'jazzcash', '2023-06-19'),
('11','29',' 7', 'Meezan Bank', '2023-06-20'),
('12','30',' 8', 'Bank HBL', '2023-06-21'),
('13','38', '5', 'easypesa', '2023-06-22'),
('14','26',' 6', 'Bank HBL', '2023-06-23'),
('15','40',' 7', 'jazzcash', '2023-06-24'),
('16','29', '8', 'Meezan Bank', '2023-06-25'),
('17','24',' 5', 'Bank HBL', '2023-06-26'),
('18','35',' 6', 'Meezan Bank', '2023-06-27'),
('19','21', '7', 'easypesa', '2023-06-28'),
('20','28',' 8', 'jazzcash', '2023-06-29');



