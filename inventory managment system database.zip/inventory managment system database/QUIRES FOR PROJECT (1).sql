

--1.SELECT QUIRES ---->>>> 40 
--2.UPDATE QUIRES ---->>>> 40 
--3.FUNCTION QUIRES ---->>>> 94 
--      =>SUM FUNCTION 
--	  =>AVERAGE FUNCTION
--	  =>MAX FUNCTION
--	  =>MIN FUNCTION
--	  =>COUNT FUNCTION
--	  =>TOP
--4. SUB  QUIRES----->>>>20
--5.JOINS QUIRES ---->>>> 40
--      =>JOIN
--	  =>LEFT JOIN
--	  =>RIGHT JOIN
--	  =>FULL JOIN
--	  =>CROSS JOIN
----6.PROCEDURE QUIRES------>>>>> 27 
--    =>INSERT
--	  =>UPDATE
--	  =>DELETE

----7.TRIGGER QUIRES------>>>>> 27 
--    =>INSERT
--	  =>UPDATE
--	  =>DELETE

----8.TRANSATION QUIRES------>>>>> 9 
--    =>INSERT




--==============================40>>>>>>>>>>>SELECT QUIRES  <<<<<<<<<<<<40=============================
--1 Retrieve all users:
SELECT * FROM users;
-- 2 Retrieve all customers:
SELECT * FROM customer;
--3 Retrieve all menu types:

SELECT * FROM menutype;
-- 4 Retrieve all menu items:

SELECT * FROM menu;
-- 5 Retrieve all orders:

SELECT * FROM orders;
-- 6 Retrieve all order details:

SELECT * FROM orderdetail;

-- 7 Retrieve all payments:

SELECT * FROM payment;

-- 9 Retrieve users with a specific email:

SELECT * FROM users
WHERE E_MAIL = 'manan@gmail.com';

--10 Retrieve customers with a specific status:

SELECT * FROM customer
WHERE CUSTOMER_STATUS = 'YES';
-- 11 Retrieve menu items with a specific status:

SELECT * FROM menu
WHERE ITEM_STATUS = 'YES';
-- 12 Retrieve orders with a specific status and amount greater than a certain value:

SELECT * FROM orders
WHERE ORDER_STATUS = 'DONE' AND AMOUNT > 100;

--13Retrieve order details with a specific quantity:

SELECT * FROM orderdetail
WHERE QUANTITY = 2;

-- 14 Retrieve payments made on a specific date:

SELECT * FROM payment
WHERE PAYMENT_DATE = '2023-06-19';


-- 16 Retrieve customers with a specific address:

SELECT * FROM customer
WHERE CUSTOMER_ADDRESS = 'lahore';


-- 17 Retrieve menu items with a specific price range:

SELECT * FROM menu
WHERE PRICE BETWEEN 120 and 350;


-- 18 Retrieve orders placed by a specific customer on a specific date:

SELECT * FROM orders
WHERE CUSTOMER_ID = 10 AND ORDER_DATE = '2023-06-11';


--19 Retrieve menu items with a specific menu type:

SELECT * FROM menu
WHERE MENU_TYPE = 1;


-- 20 Retrieve orders with a specific customer ID and order status:

SELECT * FROM orders
WHERE CUSTOMER_ID = 25 AND ORDER_STATUS = 'DONE';


-- 21 Retrieve order details with a specific total amount range:

SELECT * FROM orderdetail
WHERE TOTAL_AMOUNT BETWEEN 50 AND 100;


-- 22 Retrieve payments made by a specific user:

SELECT * FROM payment
WHERE USERs_ID = 5;


-- 24 Retrieve customers with a specific email domain:

SELECT * FROM customer
WHERE E_MAIL LIKE '%@gamil.com';


--25 Retrieve menu items with a specific item name:

SELECT * FROM menu
WHERE ITEM_NAME = 'Pizza';


-- 26 Retrieve orders placed on a specific date or later:

SELECT * FROM orders
WHERE ORDER_DATE >= '2023-06-15';

-- 27 Retrieve payments made with a specific payment method:

SELECT * FROM payment
WHERE PAYMENT_METHOD = 'easypesa';


-- 28 Retrieve users with a specific full name:

SELECT * FROM users
WHERE FullNAME = 'IQRA';


-- 29 Retrieve customers with a specific last name:

SELECT * FROM customer
WHERE LastNAME = 'naim';


-- 30 Retrieve menu items with a specific price greater than a certain value:

SELECT * FROM menu
WHERE PRICE > 15;


-- 31 Retrieve orders with a specific amount less than a certain value:

SELECT * FROM orders
WHERE AMOUNT < 20000;


-- 32 Retrieve order details with a specific menu item ID:

SELECT * FROM orderdetail
WHERE MENU_ID = 4;


-- 33 Retrieve payments made before a specific date:

SELECT * FROM payment
WHERE PAYMENT_DATE < '2023-06-21';



-- 35Retrieve customers with a specific status and address:

SELECT * FROM customer
WHERE CUSTOMER_STATUS = 'YES' AND CUSTOMER_ADDRESS = 'islamabad';


-- 36 Retrieve menu items with a specific menu type and status:

SELECT * FROM menu
WHERE MENU_TYPE = 2 AND ITEM_STATUS = 'YES';


-- 37 Retrieve orders with a specific customer ID and amount greater than a certain value:

SELECT * FROM orders
WHERE CUSTOMER_ID = 21 AND AMOUNT > 200;


-- 38 Retrieve users with a specific email and password:

SELECT * FROM users
WHERE E_MAIL = 'zain@gamil.com' AND PASSWORD = '11223344';


-- 39 Retrieve customers with a specific first name and status:

SELECT * FROM customer
WHERE FirstNAME = 'sami' AND CUSTOMER_STATUS = 'NO';


-- 40 Retrieve menu items with a specific price less than a certain value:

SELECT * FROM menu
WHERE PRICE < 200;


--==============================40>>>>>>>>>>> UPDATE QUIRES<<<<<<<<<<<<40=============================


-- 1 Update the customer's last name:

UPDATE customer
SET LastNAME = 'saim'
WHERE ID = 16;


-- 2 Update the menu item status to 'NO':

UPDATE menu
SET ITEM_STATUS = 'NO'
WHERE ID = 1;
-- 3 Update the order status to 'DONE' for a specific order:

UPDATE orders
SET ORDER_STATUS = 'DONE'
WHERE ID = 19;


-- 4 Update the order detail quantity:

UPDATE orderdetail
SET QUANTITY = 3
WHERE ID = 1;


-- 5 Update the payment method for a specific payment:

UPDATE payment
SET PAYMENT_METHOD = 'Cash'
WHERE ID = 1;




-- 7 Update the customer's email:

UPDATE customer
SET E_MAIL = 'bm@gamil.com'
WHERE ID = 21;


-- 8 Update the menu item price:

UPDATE menu
SET PRICE = 250
WHERE ID = 27;

-- 9  Update the order amount:

UPDATE orders
SET AMOUNT = 150
WHERE ID = 1;


-- 10 Update the payment date for a specific payment:

UPDATE payment
SET PAYMENT_DATE = '2023-06-10'
WHERE ID = 1;


-- 11 Update the customer's status to 'NO':

UPDATE customer
SET CUSTOMER_STATUS = 'NO'
WHERE ID = 1;


-- 12 Update the menu item name:

UPDATE menu
SET ITEM_NAME = 'Burger'
WHERE ID = 1;


-- 13 Update the order status to 'NO' for all orders placed by a specific customer:

UPDATE orders
SET ORDER_STATUS = 'NO'
WHERE CUSTOMER_ID = 1;


-- 14 Update the order detail total amount:

UPDATE orderdetail
SET TOTAL_AMOUNT = 50
WHERE ID = 1;


-- 15 Update the payment method for all payments made on a specific date:

UPDATE payment
SET PAYMENT_METHOD = 'Credit Card'
WHERE PAYMENT_DATE = '2023-06-16';



-- 17 Update the customer's address:

UPDATE customer
SET CUSTOMER_ADDRESS = 'DHA 6'
WHERE ID = 1;
--


-- 18 Update the menu item status to 'YES':

UPDATE menu
SET ITEM_STATUS = 'YES'
WHERE ID = 1;


-- 19 Update the order amount for all orders placed by a specific customer:

UPDATE orders
SET AMOUNT = 100
WHERE CUSTOMER_ID = 1;

-- 20 Update the payment date for all payments made with a specific payment method:

UPDATE payment
SET PAYMENT_DATE = '2023-06-15'
WHERE PAYMENT_METHOD = 'Credit Card';


-- 21 Update the customer's first name:

UPDATE customer
SET FirstNAME = 'RAIMA'
WHERE ID = 23;

-- 22 Update the customer's last name and email:

UPDATE customer
SET LastNAME = 'AKBAR', E_MAIL = 'mm@gamil.com'
WHERE ID = 1;


-- 23 Update the menu item status to 'YES' for a specific menu item:

UPDATE menu
SET ITEM_STATUS = 'YES'
WHERE ID = 1;


-- 24 Update the order status to 'DONE' for all orders placed by a specific customer:

UPDATE orders
SET ORDER_STATUS = 'DONE'
WHERE CUSTOMER_ID = 1;


-- 25 Update the order detail quantity and total amount:

UPDATE orderdetail
SET QUANTITY = 3, TOTAL_AMOUNT = 75
WHERE ID = 1;

-- 26 Update the payment method and payment date for a specific payment:

UPDATE payment
SET PAYMENT_METHOD = 'Cash', PAYMENT_DATE = '2023-06-10'
WHERE ID = 1;
-- 27 Update the wishlist item for a specific customer and menu item:

UPDATE wishlist
SET manu_id = 4
WHERE customer_id = 1 AND manu_id = 3;


-- 28 Update the customer's email and password:

UPDATE customer
SET E_MAIL = 'hy@gamil.com', PASSWORD = '67'
WHERE ID = 1;


-- 29 Update the menu item price and item status:

UPDATE menu
SET PRICE = 15, ITEM_STATUS = 'YES'
WHERE ID = 1;


-- 30 Update the order amount and order date for a specific order:

UPDATE orders
SET AMOUNT = 150, ORDER_DATE = '2023-06-20'
WHERE ID = 1;


-- 31 Update the payment method for all payments made by a specific user:

UPDATE payment
SET PAYMENT_METHOD = 'PayPal'
WHERE USERs_ID = 2;

-- 32 Update the customer's status and address:

UPDATE customer
SET CUSTOMER_STATUS = 'NO', CUSTOMER_ADDRESS = 'raiwand'
WHERE ID = 19;


-- 33 Update the menu item name and price:

UPDATE menu
SET ITEM_NAME = 'Chicken Sandwich', PRICE = 450
WHERE ID = 1;


-- 34 Update the order status to 'NO' for all orders placed on a specific date:

UPDATE orders
SET ORDER_STATUS = 'NO'
WHERE ORDER_DATE = '2023-06-24';

-- 35 Update the order detail total amount for a specific order detail:

UPDATE orderdetail
SET TOTAL_AMOUNT = 50
WHERE ID = 1;


-- 36 Update the payment method and payment date for all payments made by a specific user:

UPDATE payment
SET PAYMENT_METHOD = 'Credit Card', PAYMENT_DATE = '2023-06-15'
WHERE USERs_ID = 2;



-- 38 Update the customer's first name and last name:

UPDATE customer
SET FirstNAME = 'Robert', LastNAME = 'Johnson'
WHERE ID = 20;

-- 39 Update the order status to 'DONE' for all orders with an amount greater than 100:

UPDATE orders
SET ORDER_STATUS = 'DONE'
WHERE AMOUNT > 100;


-- 40 Update the payment method for all payments made by a specific user and on a specific date:

UPDATE payment
SET PAYMENT_METHOD = 'Cash'
WHERE USERs_ID = 2 AND PAYMENT_DATE = '2023-06-15';


--==============================94>>>>>>>>>>> FUNCTION QUIRES<<<<<<<<<<<<94=============================

--===================>>>>>>>>>>>    SUM FUCTION (20)

-- 1 Calculate the total amount for all orders:

SELECT SUM(AMOUNT) AS TotalAmount
FROM orders;


-- 2 Calculate the total quantity of items in the order details:

SELECT SUM(QUANTITY) AS TotalQuantity
FROM orderdetail;


-- 3 Calculate the total price of all menu items:

SELECT SUM(PRICE) AS TotalPrice
FROM menu;


-- 4 Calculate the total amount for all orders:

SELECT SUM(AMOUNT) AS TotalAmount
FROM orders;


-- 5 Calculate the total amount of orders for each customer:

SELECT CUSTOMER_ID, SUM(AMOUNT) AS TotalAmount
FROM orders
GROUP BY CUSTOMER_ID;


-- 6 Calculate the total amount of orders placed on each date:

SELECT ORDER_DATE, SUM(AMOUNT) AS TotalAmount
FROM orders
GROUP BY ORDER_DATE;


-- 7 Calculate the total quantity of items ordered by each customer:

SELECT ORDER_ID, SUM(QUANTITY) AS TotalQuantity
FROM orderdetail
GROUP BY ORDER_ID;


-- 8 Calculate the total price of items in each menu type:

SELECT MENU_TYPE, SUM(PRICE) AS TotalPrice
FROM menu
GROUP BY MENU_TYPE;

-- 9 Calculate the total quantity of items in the order details:

SELECT SUM(QUANTITY) AS TotalQuantity
FROM orderdetail;

-- 10 Calculate the total quantity of items ordered on each date:

SELECT ORDER_ID, SUM(QUANTITY) AS TotalQuantity
FROM orderdetail
GROUP BY ORDER_ID;

-- 11 Calculate the total amount of orders with 'DONE' status:

SELECT SUM(AMOUNT) AS TotalAmount
FROM orders
WHERE ORDER_STATUS = 'DONE';


-- 12 Calculate the total quantity of items ordered by all customers:

SELECT SUM(QUANTITY) AS TotalQuantity
FROM orderdetail
JOIN orders ON orderdetail.ORDER_ID = orders.ID;


-- 13 Calculate the total price of items with 'YES' status:

SELECT SUM(PRICE) AS TotalPrice
FROM menu
WHERE ITEM_STATUS = 'YES';


-- 14 Calculate the total amount paid for orders with 'DONE' status:

SELECT SUM(AMOUNT) AS TotalAmountPaid
FROM payment
JOIN orders ON payment.ORDER_ID = orders.ID
WHERE orders.ORDER_STATUS = 'DONE';


-- 15 Calculate the total quantity of items ordered by a specific customer on a specific date:

SELECT orders.CUSTOMER_ID, SUM(orderdetail.QUANTITY) AS TotalQuantity
FROM orderdetail
JOIN orders ON orderdetail.ORDER_ID = orders.ID
WHERE orders.CUSTOMER_ID = 19 AND orders.ORDER_DATE = '2023-06-20'
GROUP BY orders.CUSTOMER_ID;


-- 16 Calculate the total amount of orders with 'NO' status for each customer:

SELECT CUSTOMER_ID, SUM(AMOUNT) AS TotalAmount
FROM orders
WHERE ORDER_STATUS = 'NO'
GROUP BY CUSTOMER_ID;


  -- 17 Calculate the total quantity of items ordered in each menu type:

SELECT menu.MENU_TYPE, SUM(orderdetail.QUANTITY) AS TotalQuantity
FROM orderdetail
JOIN menu ON orderdetail.MENU_ID = menu.ID
GROUP BY menu.MENU_TYPE;



-- 18 Calculate the total price of all menu items:

SELECT SUM(PRICE) AS TotalPrice
FROM menu;

-- 19 Calculate the total amount of orders for a specific customer:

SELECT SUM(AMOUNT) AS TotalAmount
FROM orders
WHERE CUSTOMER_ID = 16;

-- 20 Calculate the total amount of orders placed on a specific date:

SELECT SUM(AMOUNT) AS TotalAmount
FROM orders
WHERE ORDER_DATE = '2023-06-15';


-- =========================>>>>>>>>>>>>>>>>>> AVERAGE FUNCTION (15)

-- 1 Calculate the average price of all menu items:

SELECT AVG(PRICE) AS AveragePrice
FROM menu;


-- 2 Calculate the average quantity of items in the order details:

SELECT AVG(QUANTITY) AS AverageQuantity
FROM orderdetail;


-- 3 Calculate the average amount of orders for each customer:

SELECT CUSTOMER_ID, AVG(AMOUNT) AS AverageAmount
FROM orders
GROUP BY CUSTOMER_ID;


-- 4 Calculate the average amount of orders placed on each date:

SELECT ORDER_DATE, AVG(AMOUNT) AS AverageAmount
FROM orders
GROUP BY ORDER_DATE;


-- 5 Calculate the average quantity of items ordered by each customer:

SELECT ORDER_ID, AVG(QUANTITY) AS AverageQuantity
FROM orderdetail
GROUP BY ORDER_ID;


-- 6 Calculate the average price of items in each menu type:

SELECT MENU_TYPE, AVG(PRICE) AS AveragePrice
FROM menu
GROUP BY MENU_TYPE;

-- 7 Calculate the average quantity of items ordered on each date:

SELECT ORDER_ID, AVG(QUANTITY) AS AverageQuantity
FROM orderdetail
GROUP BY ORDER_ID;


-- 8 Calculate the average amount of orders with 'DONE' status:

SELECT AVG(AMOUNT) AS AverageAmount
FROM orders
WHERE ORDER_STATUS = 'DONE';


-- 09 Calculate the average quantity of items ordered by all customers:

SELECT AVG(QUANTITY) AS AverageQuantity
FROM orderdetail
JOIN orders ON orderdetail.ORDER_ID = orders.ID;


-- 10 Calculate the average price of items with 'YES' status:

SELECT AVG(PRICE) AS AveragePrice
FROM menu
WHERE ITEM_STATUS = 'YES';


-- 11 Calculate the average amount paid for orders with 'DONE' status:

SELECT AVG(AMOUNT) AS AverageAmountPaid
FROM payment
JOIN orders ON payment.ORDER_ID = orders.ID
WHERE orders.ORDER_STATUS = 'DONE';


 -- 12 Calculate the average quantity of items ordered by a specific customer on a specific date:

SELECT orders.CUSTOMER_ID, AVG(orderdetail.QUANTITY) AS AverageQuantity
FROM orderdetail
JOIN orders ON orderdetail.ORDER_ID = orders.ID
WHERE orders.CUSTOMER_ID = 19 AND orders.ORDER_DATE = '2023-06-15'
GROUP BY orders.CUSTOMER_ID;


-- 13 Calculate the average amount of orders with 'NO' status for each customer:

SELECT CUSTOMER_ID, AVG(AMOUNT) AS AverageAmount
FROM orders
WHERE ORDER_STATUS = 'NO'
GROUP BY CUSTOMER_ID;


-- 14 Calculate the average quantity of items ordered in each menu type:

SELECT menu.MENU_TYPE, AVG(orderdetail.QUANTITY) AS AverageQuantity
FROM orderdetail
JOIN menu ON orderdetail.MENU_ID = menu.ID
GROUP BY menu.MENU_TYPE;


-- 15 Calculate the average amount of orders for each customer and date:

SELECT CUSTOMER_ID, ORDER_DATE, AVG(AMOUNT) AS AverageAmount
FROM orders
GROUP BY CUSTOMER_ID, ORDER_DATE;


--========================>>>>>>>>>>>>>>>>>>>> MAX FUNCTION (16)

-- 1 Retrieve the highest price among all menu items:

SELECT MAX(PRICE) AS HighestPrice
FROM menu;


-- 2 Retrieve the maximum quantity of items in the order details:

SELECT MAX(QUANTITY) AS MaximumQuantity
FROM orderdetail;


-- 3  Retrieve the maximum amount of orders for each customer:

SELECT CUSTOMER_ID, MAX(AMOUNT) AS MaximumAmount
FROM orders
GROUP BY CUSTOMER_ID;


-- 4 Retrieve the maximum amount of orders placed on each date:

SELECT ORDER_DATE, MAX(AMOUNT) AS MaximumAmount
FROM orders
GROUP BY ORDER_DATE;

-- 5 Retrieve the maximum quantity of items ordered by each customer:

SELECT ORDER_ID, MAX(QUANTITY) AS MaximumQuantity
FROM orderdetail
GROUP BY ORDER_ID;


-- 6 Retrieve the highest price of items in each menu type:

SELECT MENU_TYPE, MAX(PRICE) AS HighestPrice
FROM menu
GROUP BY MENU_TYPE;


-- 777777777 MISS

-- 8 Retrieve the maximum quantity of items ordered on each date:

SELECT ORDER_ID, MAX(QUANTITY) AS MaximumQuantity
FROM orderdetail
GROUP BY ORDER_ID;


-- 9 Retrieve the maximum amount of orders with 'DONE' status:

SELECT MAX(AMOUNT) AS MaximumAmount
FROM orders
WHERE ORDER_STATUS = 'DONE';


-- 10 Retrieve the maximum quantity of items ordered by all customers:

SELECT MAX(QUANTITY) AS MaximumQuantity
FROM orderdetail
JOIN orders ON orderdetail.ORDER_ID = orders.ID;


-- 11 Retrieve the highest price of items with 'YES' status:

SELECT MAX(PRICE) AS HighestPrice
FROM menu
WHERE ITEM_STATUS = 'YES';


-- 12 Retrieve the maximum amount paid for orders with 'DONE' status:

SELECT MAX(AMOUNT) AS MaximumAmountPaid
FROM payment
JOIN orders ON payment.ORDER_ID = orders.ID
WHERE orders.ORDER_STATUS = 'DONE';


-- 13 Retrieve the maximum quantity of items ordered by a specific customer on a specific date:

SELECT orders.CUSTOMER_ID, MAX(orderdetail.QUANTITY) AS MaximumQuantity
FROM orderdetail
JOIN orders ON orderdetail.ORDER_ID = orders.ID
WHERE orders.CUSTOMER_ID = 19 AND orders.ORDER_DATE = '2023-06-15'
GROUP BY orders.CUSTOMER_ID;


-- 14 Retrieve the maximum amount of orders with 'NO' status for each customer:

SELECT CUSTOMER_ID, MAX(AMOUNT) AS MaximumAmount
FROM orders
WHERE ORDER_STATUS = 'NO'
GROUP BY CUSTOMER_ID;


-- 15 Retrieve the maximum quantity of items ordered in each menu type:

SELECT menu.MENU_TYPE, MAX(orderdetail.QUANTITY) AS MaximumQuantity
FROM orderdetail
JOIN menu ON orderdetail.MENU_ID = menu.ID
GROUP BY menu.MENU_TYPE;


-- 16 Retrieve the maximum amount of orders for each customer and date:

SELECT CUSTOMER_ID, ORDER_DATE, MAX(AMOUNT) AS MaximumAmount
FROM orders
GROUP BY CUSTOMER_ID, ORDER_DATE;



-- =====================>>>>>>>>>>>>>>>>> MIN FUNCTION  (15)


-- 1 Retrieve the lowest price among all menu items:

SELECT MIN(PRICE) AS LowestPrice
FROM menu;


-- 2 Retrieve the minimum quantity of items in the order details:

SELECT MIN(QUANTITY) AS MinimumQuantity
FROM orderdetail;




-- 3 Retrieve the minimum amount of orders for each customer:

SELECT CUSTOMER_ID, MIN(AMOUNT) AS MinimumAmount
FROM orders
GROUP BY CUSTOMER_ID;


-- 4 Retrieve the minimum amount of orders placed on each date:

SELECT ORDER_DATE, MIN(AMOUNT) AS MinimumAmount
FROM orders
GROUP BY ORDER_DATE;


-- 5 Retrieve the minimum quantity of items ordered by each customer:

SELECT ORDER_ID, MIN(QUANTITY) AS MinimumQuantity
FROM orderdetail
GROUP BY ORDER_ID;


-- 6 Retrieve the lowest price of items in each menu type:

SELECT MENU_TYPE, MIN(PRICE) AS LowestPrice
FROM menu
GROUP BY MENU_TYPE;


-- 7 Retrieve the minimum quantity of items ordered on each date:

SELECT ORDER_ID, MIN(QUANTITY) AS MinimumQuantity
FROM orderdetail
GROUP BY ORDER_ID;


-- 8 Retrieve the minimum amount of orders with 'DONE' status:

SELECT MIN(AMOUNT) AS MinimumAmount
FROM orders
WHERE ORDER_STATUS = 'DONE';


-- 9 Retrieve the minimum quantity of items ordered by all customers:

SELECT MIN(QUANTITY) AS MinimumQuantity
FROM orderdetail
JOIN orders ON orderdetail.ORDER_ID = orders.ID;


-- 10 Retrieve the lowest price of items with 'YES' status:

SELECT MIN(PRICE) AS LowestPrice
FROM menu
WHERE ITEM_STATUS = 'YES';


-- 11 Retrieve the minimum amount paid for orders with 'DONE' status:

SELECT MIN(AMOUNT) AS MinimumAmountPaid
FROM payment
JOIN orders ON payment.ORDER_ID = orders.ID
WHERE orders.ORDER_STATUS = 'DONE';


-- 12 Retrieve the minimum quantity of items ordered by a specific customer on a specific date:

SELECT orders.CUSTOMER_ID, MIN(orderdetail.QUANTITY) AS MinimumQuantity
FROM orderdetail
JOIN orders ON orderdetail.ORDER_ID = orders.ID
WHERE orders.CUSTOMER_ID = 1 AND orders.ORDER_DATE = '2023-06-15'
GROUP BY orders.CUSTOMER_ID;


-- 13 Retrieve the minimum amount of orders with 'NO' status for each customer:

SELECT CUSTOMER_ID, MIN(AMOUNT) AS MinimumAmount
FROM orders
WHERE ORDER_STATUS = 'NO'
GROUP BY CUSTOMER_ID;


-- 14 Retrieve the minimum quantity of items ordered in each menu type:

SELECT menu.MENU_TYPE, MIN(orderdetail.QUANTITY) AS MinimumQuantity
FROM orderdetail
JOIN menu ON orderdetail.MENU_ID = menu.ID
GROUP BY menu.MENU_TYPE;


-- 15 Retrieve the minimum amount of orders for each customer and date:

SELECT CUSTOMER_ID, ORDER_DATE, MIN(AMOUNT) AS MinimumAmount
FROM orders
GROUP BY CUSTOMER_ID, ORDER_DATE;


--====================== >>>>>>>>>>>>>>>>>> TOP (8)

-- 1 Retrieve the top 5 highest priced menu items:

SELECT TOP 5 ITEM_NAME, PRICE
FROM menu
ORDER BY PRICE DESC;


-- 2 Retrieve the top 10 customers with the highest total order amounts:

SELECT TOP 10 customer.ID, FirstNAME, LastNAME, SUM(orders.AMOUNT) AS TotalAmount
FROM customer
JOIN orders ON customer.ID = orders.CUSTOMER_ID
GROUP BY customer.ID, FirstNAME, LastNAME
ORDER BY TotalAmount DESC;


-- 3 Retrieve the top 3 most popular menu types based on the number of orders:

SELECT TOP 3 menutype.TYPES_NAME, COUNT(orderdetail.MENU_ID) AS TotalOrders
FROM menutype
JOIN menu ON menutype.ID = menu.MENU_TYPE
JOIN orderdetail ON menu.ID = orderdetail.MENU_ID
GROUP BY menutype.TYPES_NAME
ORDER BY TotalOrders DESC;


-- 4 Retrieve the top 5 customers who have placed the most orders:

SELECT TOP 5 customer.ID, FirstNAME, LastNAME, COUNT(orders.ID) AS TotalOrders
FROM customer
JOIN orders ON customer.ID = orders.CUSTOMER_ID
GROUP BY customer.ID, FirstNAME, LastNAME
ORDER BY TotalOrders DESC;





-- 6 Retrieve the top 5 menu items with the highest quantity ordered:

SELECT TOP 5 menu.ITEM_NAME, SUM(orderdetail.QUANTITY) AS TotalQuantity
FROM menu
JOIN orderdetail ON menu.ID = orderdetail.MENU_ID
GROUP BY menu.ITEM_NAME
ORDER BY TotalQuantity DESC;


-- 7 Retrieve the top 10 customers with the highest average order amounts:

SELECT TOP 10 customer.ID, FirstNAME, LastNAME, AVG(orders.AMOUNT) AS AverageAmount
FROM customer
JOIN orders ON customer.ID = orders.CUSTOMER_ID
GROUP BY customer.ID, FirstNAME, LastNAME
ORDER BY AverageAmount DESC;



-- 8 Retrieve the top 3 most frequently ordered menu items:

SELECT TOP 3 menu.ITEM_NAME, COUNT(orderdetail.ORDER_ID) AS TotalOrders
FROM menu
JOIN orderdetail ON menu.ID = orderdetail.MENU_ID
GROUP BY menu.ITEM_NAME
ORDER BY TotalOrders DESC;


--           ===============>>>>>>>>>>>>>>>>>>> COUNT FUNCTION (20)

-- 1 Count the total number of users in the database:

SELECT COUNT(*) AS TotalUsers
FROM users;


-- 2 Count the number of distinct menu types available:

SELECT COUNT(DISTINCT MENU_TYPE) AS TotalMenuTypes
FROM menu;


-- 3 Count the total number of customers in the database:

SELECT COUNT(*) AS TotalCustomers
FROM customer;


--  4 Count the number of active customers (customers with CUSTOMER_STATUS = 'YES'):

SELECT COUNT(*) AS ActiveCustomers
FROM customer
WHERE CUSTOMER_STATUS = 'YES';


-- 5 Count the total number of orders placed:

SELECT COUNT(*) AS TotalOrders
FROM orders;


--  6 Count the number of orders with 'DONE' status:

SELECT COUNT(*) AS DoneOrders
FROM orders
WHERE ORDER_STATUS = 'DONE';


-- 7 Count the total number of menu items available:

SELECT COUNT(*) AS TotalMenuItems
FROM menu;


-- 8 Count the number of menu items with 'YES' status:

SELECT COUNT(*) AS AvailableMenuItems
FROM menu
WHERE ITEM_STATUS = 'YES';


-- 9 Count the total number of order details:

SELECT COUNT(*) AS TotalOrderDetails
FROM orderdetail;


-- 10 Count the number of payments made:

SELECT COUNT(*) AS TotalPayments
FROM payment;


-- 11 Count the total number of menu items in each menu type:

SELECT menu.MENU_TYPE, COUNT(*) AS MenuTypeCount
FROM menu
GROUP BY menu.MENU_TYPE;


-- 12 Count the number of orders placed by each customer:

SELECT orders.CUSTOMER_ID, COUNT(*) AS OrderCount
FROM orders
GROUP BY orders.CUSTOMER_ID;


-- 13 Count the total number of orders placed on each date:

SELECT ORDER_DATE, COUNT(*) AS OrderCount
FROM orders
GROUP BY ORDER_DATE;


-- 14 Count the number of menu items ordered in each order:

SELECT orderdetail.ORDER_ID, COUNT(*) AS MenuItemCount
FROM orderdetail
GROUP BY orderdetail.ORDER_ID;


-- 15 Count the total number of payments made by each user:

SELECT payment.USERs_ID, COUNT(*) AS PaymentCount
FROM payment
GROUP BY payment.USERs_ID;


-- 16 Count the number of wishlist items for each customer:

SELECT wishlist.customer_id, COUNT(*) AS WishlistCount
FROM wishlist
GROUP BY wishlist.customer_id;


--17 Count the total number of orders for each customer and menu item:

SELECT orders.CUSTOMER_ID, orderdetail.MENU_ID, COUNT(*) AS OrderCount
FROM orders
JOIN orderdetail ON orders.ID = orderdetail.ORDER_ID
GROUP BY orders.CUSTOMER_ID, orderdetail.MENU_ID;


-- 18 Count the number of menu items with a price greater than 50:

SELECT COUNT(*) AS MenuItemCount
FROM menu
WHERE PRICE > 50;


 --19 Count the total number of orders with an amount greater than 100:

SELECT COUNT(*) AS OrderCount
FROM orders
WHERE AMOUNT > 100;
-- 20 Count the number of payments made on a specific date:

SELECT COUNT(*) AS PaymentCount
FROM payment
WHERE PAYMENT_DATE = '2023-06-15';


--==============================20>>>>>>>>>>> SUB  QUIRES<<<<<<<<<<<<20=============================

-- 1 Retrieve the menu items with a price higher than the average price:

SELECT ITEM_NAME, PRICE
FROM menu
WHERE PRICE > (SELECT AVG(PRICE) FROM menu);


-- 2 Retrieve the customers who have placed more orders than the average number of orders:

SELECT FirstNAME, LastNAME
FROM customer
WHERE (SELECT COUNT(*) FROM orders WHERE orders.CUSTOMER_ID = customer.ID) > (SELECT AVG(OrderCount) FROM (SELECT COUNT(*) AS OrderCount FROM orders GROUP BY CUSTOMER_ID) AS AvgOrders);



-- 3 Retrieve the customers who have placed orders for menu items with a price greater than the average price:

SELECT FirstNAME, LastNAME
FROM customer
WHERE EXISTS (
  SELECT *
  FROM orders
  JOIN orderdetail ON orders.ID = orderdetail.ORDER_ID
  JOIN menu ON orderdetail.MENU_ID = menu.ID
  WHERE orders.CUSTOMER_ID = customer.ID
  AND menu.PRICE > (SELECT AVG(PRICE) FROM menu)
);



-- 4 Retrieve the menu items that have never been ordered:

SELECT ITEM_NAME
FROM menu
WHERE NOT EXISTS (SELECT * FROM orderdetail WHERE orderdetail.MENU_ID = menu.ID);


-- 5 Retrieve the customers who have placed orders on a specific date:

SELECT FirstNAME, LastNAME
FROM customer
WHERE EXISTS (SELECT * FROM orders WHERE orders.CUSTOMER_ID = customer.ID AND ORDER_DATE = '2023-06-15');


-- 6 Retrieve the menu items with a price higher than the maximum price of a specific menu type:

SELECT ITEM_NAME, PRICE
FROM menu
WHERE PRICE > (SELECT MAX(PRICE) FROM menu WHERE MENU_TYPE = 1);


-- 7 Retrieve the customers who have placed orders for all available menu items:

SELECT FirstNAME, LastNAME
FROM customer
WHERE NOT EXISTS (
  SELECT *
  FROM menu
  WHERE NOT EXISTS (
    SELECT *
    FROM orders
    JOIN orderdetail ON orders.ID = orderdetail.ORDER_ID
    WHERE orders.CUSTOMER_ID = customer.ID
    AND orderdetail.MENU_ID = menu.ID
  )
);



-- 8 Retrieve the menu items that have not been ordered by any customer:

SELECT ITEM_NAME
FROM menu
WHERE NOT EXISTS (SELECT * FROM orderdetail WHERE orderdetail.MENU_ID = menu.ID);


-- 9 Retrieve the customers who have placed orders for all menu types:

SELECT FirstNAME, LastNAME
FROM customer
WHERE NOT EXISTS (
  SELECT *
  FROM menutype
  WHERE NOT EXISTS (
    SELECT *
    FROM orders
    JOIN orderdetail ON orders.ID = orderdetail.ORDER_ID
    JOIN menu ON orderdetail.MENU_ID = menu.ID
    WHERE orders.CUSTOMER_ID = customer.ID
    AND menu.MENU_TYPE = menutype.ID
  )
);



-- 10 Retrieve the customers who have placed orders with a total amount higher than the average order amount:

SELECT FirstNAME, LastNAME
FROM customer
WHERE (SELECT SUM(AMOUNT) FROM orders WHERE orders.CUSTOMER_ID = customer.ID) > (SELECT AVG(OrderAmount) FROM (SELECT SUM(AMOUNT) AS OrderAmount FROM orders GROUP BY CUSTOMER_ID) AS AvgOrders);


-- 11 Retrieve the menu items that have been ordered by a specific customer:

SELECT ITEM_NAME
FROM menu
WHERE EXISTS (SELECT * FROM orderdetail WHERE orderdetail.MENU_ID = menu.ID AND orderdetail.ORDER_ID IN (SELECT ID FROM orders WHERE orders.CUSTOMER_ID = 1));


12 Retrieve the customers who have not placed any orders on a specific date:

SELECT FirstNAME, LastNAME
FROM customer
WHERE NOT EXISTS (SELECT * FROM orders WHERE orders.CUSTOMER_ID = customer.ID AND ORDER_DATE = '2023-06-15');


-- 13 Retrieve the menu items that have a higher price than the average price of their menu type:

SELECT ITEM_NAME, PRICE
FROM menu
WHERE PRICE > (SELECT AVG(PRICE) FROM menu WHERE menu.MENU_TYPE = menu.MENU_TYPE);


-- 14 Retrieve the customers who have placed orders for menu items with a price higher than the average price of their menu type:

SELECT FirstNAME, LastNAME
FROM customer
WHERE EXISTS (
  SELECT *
  FROM orders
  JOIN orderdetail ON orders.ID = orderdetail.ORDER_ID
  JOIN menu ON orderdetail.MENU_ID = menu.ID
  WHERE orders.CUSTOMER_ID = customer.ID
  AND menu.PRICE > (SELECT AVG(PRICE) FROM menu WHERE menu.MENU_TYPE = menu.MENU_TYPE)
);


-- 15 Retrieve the menu items that have been ordered by a specific customer on a specific date:

SELECT ITEM_NAME
FROM menu
WHERE EXISTS (
  SELECT *
  FROM orders
  JOIN orderdetail ON orders.ID = orderdetail.ORDER_ID
  WHERE orderdetail.MENU_ID = menu.ID
  AND orders.CUSTOMER_ID = 1
  AND orders.ORDER_DATE = '2023-06-15'
);



-- 16 Retrieve the menu items that have not been ordered by a specific customer:

SELECT ITEM_NAME
FROM menu
WHERE NOT EXISTS (SELECT * FROM orderdetail WHERE orderdetail.MENU_ID = menu.ID AND orderdetail.ORDER_ID IN (SELECT ID FROM orders WHERE orders.CUSTOMER_ID = 1));


-- 17 Retrieve the customers who have placed orders for all menu items of a specific menu type:

SELECT FirstNAME, LastNAME
FROM customer
WHERE NOT EXISTS (
  SELECT *
  FROM menu
  WHERE menu.MENU_TYPE = 1
  AND NOT EXISTS (
    SELECT *
    FROM orders
    JOIN orderdetail ON orders.ID = orderdetail.ORDER_ID
    WHERE orders.CUSTOMER_ID = customer.ID
    AND orderdetail.MENU_ID = menu.ID
  )
);


-- 18 Retrieve the menu items that have a price higher than the maximum price of all menu items:

SELECT ITEM_NAME, PRICE
FROM menu
WHERE PRICE > (SELECT MAX(PRICE) FROM menu);

-- 19 Retrieve the menu items that have been ordered by customers who have also placed orders for a specific menu item:

SELECT ITEM_NAME
FROM menu
WHERE EXISTS (
  SELECT *
  FROM orders
  JOIN orderdetail ON orders.ID = orderdetail.ORDER_ID
  WHERE orderdetail.MENU_ID = menu.ID
  AND orders.CUSTOMER_ID IN (SELECT CUSTOMER_ID FROM orderdetail WHERE MENU_ID = 1)
);


--==============================40>>>>>>>>>>> JOIN QUIRES<<<<<<<<<<<<40=============================


--1. Retrieve all orders with their corresponding customer information:

SELECT o.ID AS OrderID, c.FirstNAME, c.LastNAME, c.E_MAIL
FROM orders o
JOIN customer c ON o.CUSTOMER_ID = c.ID;


--2 Get the details of an order along with the menu items included in the order:

SELECT od.ID AS OrderDetailID, m.ITEM_NAME, m.PRICE, od.QUANTITY
FROM orderdetail od
JOIN menu m ON od.MENU_ID = m.ID
WHERE od.ORDER_ID = [order_id];

--3 Retrieve the payment details for a specific order along with the user who processed the payment:

SELECT p.ID AS PaymentID, p.PAYMENT_METHOD, p.PAYMENT_DATE, u.FullNAME AS ProcessedBy
FROM payment p
JOIN users u ON p.USERs_ID = u.ID
WHERE p.ORDER_ID = [order_id];

--4 Retrieve all orders processed by a specific user:

SELECT o.ID AS OrderID, u.FullNAME, u.E_MAIL
FROM orders o
JOIN users u ON o.USERs_ID = u.ID
WHERE u.FullNAME = 'IQRA';

 

--5Retrieve all orders that have not been processed yet:
SELECT o.ID AS OrderID, c.FirstNAME, c.LastNAME
FROM orders o
JOIN customer c ON o.CUSTOMER_ID = c.ID
WHERE o.ORDER_STATUS = 'NO';


-- 6 Retrieve the total amount spent by each customer:

SELECT c.FirstNAME, c.LastNAME, SUM(od.TOTAL_AMOUNT) AS TotalAmount
FROM customer c
JOIN orders o ON c.ID = o.CUSTOMER_ID
JOIN orderdetail od ON o.ID = od.ORDER_ID
GROUP BY c.FirstNAME, c.LastNAME;

-- 7 Retrieve the menu items and their corresponding menu types:
SELECT m.ITEM_NAME, mt.TYPES_NAME
FROM menu m
JOIN menutype mt ON m.MENU_TYPE = mt.ID;

-- 8   Retrieve all customers along with their respective wishlist items:

SELECT c.FirstNAME, c.LastNAME, m.ITEM_NAME
FROM customer c
JOIN wishlist w ON c.ID = w.customer_id
JOIN menu m ON w.manu_id = m.ID;


-- 9  Retrieve the number of orders processed by each user:

SELECT u.FullNAME, COUNT(o.ID) AS OrderCount
FROM users u
JOIN orders o ON u.ID = o.USERs_ID
GROUP BY u.FullNAME;

-- 10 Retrieve the payment details for all orders:

SELECT p.ID AS PaymentID, p.PAYMENT_METHOD, p.PAYMENT_DATE, o.ID AS OrderID
FROM payment p
JOIN orders o ON p.ORDER_ID = o.ID;

-- 11 Retrieve all customers along with their corresponding orders (including customers without orders):

SELECT c.FirstNAME, c.LastNAME, o.ID AS OrderID
FROM customer c
RIGHT JOIN orders o ON c.ID = o.CUSTOMER_ID;

--12  Retrieve all orders along with the menu items included in each order (including orders without menu items):

SELECT o.ID AS OrderID, m.ITEM_NAME, m.PRICE, od.QUANTITY
FROM orders o
RIGHT JOIN orderdetail od ON o.ID = od.ORDER_ID
JOIN menu m ON od.MENU_ID = m.ID;

-- 13 Retrieve all menu items along with their corresponding menu types (including menu items without menu types):

SELECT m.ITEM_NAME, mt.TYPES_NAME
FROM menu m
RIGHT JOIN menutype mt ON m.MENU_TYPE = mt.ID;

-- 14   Retrieve all orders along with the corresponding customer information and payment details, 
--if available (including orders without payment details):

SELECT o.ID AS OrderID, c.FirstNAME, c.LastNAME, p.PAYMENT_METHOD, p.PAYMENT_DATE
FROM orders o
JOIN customer c ON o.CUSTOMER_ID = c.ID
RIGHT JOIN payment p ON o.ID = p.ORDER_ID;


-- 15 Retrieve all customers who have not placed any orders yet (including customers without orders):

SELECT c.FirstNAME, c.LastNAME
FROM customer c
RIGHT JOIN orders o ON c.ID = o.CUSTOMER_ID
WHERE o.ID IS NULL;


-- 16 Retrieve all menu items that have not been included in any orders yet (including menu items without orders):

SELECT m.ITEM_NAME
FROM menu m
RIGHT JOIN orderdetail od ON m.ID = od.MENU_ID
WHERE od.ID IS NULL;

--   17  Retrieve all customers along with their respective wishlist items (including customers without wishlist items):

SELECT c.FirstNAME, c.LastNAME, m.ITEM_NAME
FROM customer c
RIGHT JOIN wishlist w ON c.ID = w.customer_id
JOIN menu m ON w.manu_id = m.ID;

-- 18 Retrieve all payments along with the corresponding orders and user information (including payments without orders):

SELECT p.ID AS PaymentID, p.PAYMENT_METHOD, p.PAYMENT_DATE, o.ID AS OrderID, u.FullNAME
FROM payment p
JOIN orders o ON p.ORDER_ID = o.ID
RIGHT JOIN users u ON p.USERs_ID = u.ID;


-- 19 Retrieve all menu items along with their corresponding prices, sorted by price in descending order (including menu items without prices): 

SELECT m.ITEM_NAME, m.PRICE
FROM menu m
RIGHT JOIN orderdetail od ON m.ID = od.MENU_ID
ORDER BY m.PRICE DESC;

-- 20 Retrieve all users who have not processed any orders yet (including users without orders):

SELECT u.FullNAME
FROM users u
RIGHT JOIN orders o ON u.ID = o.USERs_ID
WHERE o.ID IS NULL;


--    21Retrieve all customers along with their corresponding orders (including customers without orders): 

SELECT c.FirstNAME, c.LastNAME, o.ID AS OrderID
FROM customer c
LEFT JOIN orders o ON c.ID = o.CUSTOMER_ID;

-- 22 Retrieve all orders along with the menu items included in each order (including orders without menu items):


SELECT o.ID AS OrderID, m.ITEM_NAME, m.PRICE, od.QUANTITY
FROM orders o
LEFT JOIN orderdetail od ON o.ID = od.ORDER_ID
JOIN menu m ON od.MENU_ID = m.ID;

-- 23 Retrieve all menu items along with their corresponding menu types (including menu items without menu types):

SELECT m.ITEM_NAME, mt.TYPES_NAME
FROM menu m
LEFT JOIN menutype mt ON m.MENU_TYPE = mt.ID;

-- 24 Retrieve all orders along with the corresponding customer information and payment details, if available (including orders without payment details):

SELECT o.ID AS OrderID, c.FirstNAME, c.LastNAME, p.PAYMENT_METHOD, p.PAYMENT_DATE
FROM orders o
JOIN customer c ON o.CUSTOMER_ID = c.ID
LEFT JOIN payment p ON o.ID = p.ORDER_ID;

-- 25 Retrieve all customers who have not placed any orders yet (including customers without orders):

SELECT c.FirstNAME, c.LastNAME
FROM customer c
LEFT JOIN orders o ON c.ID = o.CUSTOMER_ID
WHERE o.ID IS NULL;


-- 26 Retrieve all menu items that have not been included in any orders yet (including menu items without orders):
SELECT m.ITEM_NAME
FROM menu m
LEFT JOIN orderdetail od ON m.ID = od.MENU_ID
WHERE od.ID IS NULL;

-- 27 Retrieve all customers along with their respective wishlist items (including customers without wishlist items):

SELECT c.FirstNAME, c.LastNAME, m.ITEM_NAME
FROM customer c
LEFT JOIN wishlist w ON c.ID = w.customer_id
JOIN menu m ON w.manu_id = m.ID;

-- 28 Retrieve all payments along with the corresponding orders and user information (including payments without orders):

SELECT p.ID AS PaymentID, p.PAYMENT_METHOD, p.PAYMENT_DATE, o.ID AS OrderID, u.FullNAME
FROM payment p
JOIN orders o ON p.ORDER_ID = o.ID
LEFT JOIN users u ON p.USERs_ID = u.ID;

-- 29 Retrieve all menu items along with their corresponding prices, sorted by price in descending order (including menu items without prices):
SELECT m.ITEM_NAME, m.PRICE
FROM menu m
LEFT JOIN orderdetail od ON m.ID = od.MENU_ID
ORDER BY m.PRICE DESC;


-- 30 Retrieve all users who have not processed any orders yet (including users without orders):

SELECT u.FullNAME
FROM users u
LEFT JOIN orders o ON u.ID = o.USERs_ID
WHERE o.ID is null ;


-- 31 Retrieve all orders along with the customer information, displaying NULL for customers without orders:
SELECT o.ID AS OrderID, c.FirstNAME, c.LastNAME
FROM orders o
LEFT JOIN customer c ON o.CUSTOMER_ID = c.ID;

-- 32 Retrieve all possible combinations of customers and menu items:
SELECT c.FirstNAME, c.LastNAME, m.ITEM_NAME
FROM customer c
CROSS JOIN menu m;

-- 33 Retrieve all possible combinations of orders and payment methods:

SELECT o.ID AS OrderID, p.PAYMENT_METHOD
FROM orders o
CROSS JOIN payment p;

-- 34 Retrieve all possible combinations of menu items and order details:
SELECT m.ITEM_NAME, od.QUANTITY
FROM menu m
CROSS JOIN orderdetail od;

-- 35 Retrieve all possible combinations of users and customers:
SELECT u.FullNAME, c.FirstNAME, c.LastNAME
FROM users u
CROSS JOIN customer c;

-- 36 Retrieve all possible combinations of menu items and menu types:
SELECT m.ITEM_NAME, mt.TYPES_NAME
FROM menu m
CROSS JOIN menutype mt;
 
-- 37 Retrieve all possible combinations of orders and users:
SELECT o.ID AS OrderID, u.FullNAME
FROM orders o
CROSS JOIN users u;


-- 38 Retrieve all possible combinations of customers and order details:
SELECT c.FirstNAME, c.LastNAME, od.QUANTITY
FROM customer c
CROSS JOIN orderdetail od;

-- 39  Retrieve all possible combinations of menu items, orders, and payments:
SELECT m.ITEM_NAME, o.ID AS OrderID, p.PAYMENT_METHOD
FROM menu m
CROSS JOIN orders o
CROSS JOIN payment p;



-- 40 Retrieve all possible combinations of menu types, orders, and users:

SELECT mt.TYPES_NAME, o.ID AS OrderID, u.FullNAME
FROM menutype mt
CROSS JOIN orders o
CROSS JOIN users u;



--==============================27>>>>>>>>>>> PROCEDURE QUIRES<<<<<<<<<<<<27=============================

-- INSERT AND UPDATE AND DELETE ====>>>> USER TABLE 


-- 1
CREATE PROCEDURE InsertUser
    @FullName VARCHAR(15),
    @Contact VARCHAR(15),
    @Email VARCHAR(15),
    @Password VARCHAR(15)
AS
BEGIN
    INSERT INTO users (FullNAME, contact, E_MAIL, PASSWORD)
    VALUES (@FullName, @Contact, @Email, @Password)
END;

EXEC InsertUser 'John Doe', '03000000000', 'aligamil.com', '11111111';

-- 2

CREATE PROCEDURE UpdateUser
    @UserID INT,
    @FullName VARCHAR(15),
    @Contact VARCHAR(15),
    @Email VARCHAR(15),
    @Password VARCHAR(15)
AS
BEGIN
    UPDATE users
    SET FullNAME = @FullName,
        contact = @Contact,
        E_MAIL = @Email,
        PASSWORD = @Password
    WHERE ID = @UserID
END;

EXEC UpdateUser 5, 'abdul', '123456789', 'abdul@gamil.com', '99999999';


-- 3 

CREATE PROCEDURE DeleteUser
    @UserID INT
AS
BEGIN
    DELETE FROM users
    WHERE ID = @UserID
END;


EXEC DeleteUser 5;

-- INSERT AND UPDATE AND DELETE ====>>>> customer TABLE 
--1

CREATE PROCEDURE InsertCustomer
    @FirstName VARCHAR(15),
    @LastName VARCHAR(15),
    @Contact VARCHAR(15),
    @Email VARCHAR(15),
    @Password VARCHAR(15),
    @CustomerStatus VARCHAR(10),
    @CustomerAddress VARCHAR(50)
AS
BEGIN
    INSERT INTO customer (FirstNAME, LastNAME, contact, E_MAIL, PASSWORD, CUSTOMER_STATUS, CUSTOMER_ADDRESS)
    VALUES (@FirstName, @LastName, @Contact, @Email, @Password, @CustomerStatus, @CustomerAddress)
END;


--2
CREATE PROCEDURE UpdateCustomer
    @CustomerID INT,
    @FirstName VARCHAR(15),
    @LastName VARCHAR(15),
    @Contact VARCHAR(15),
    @Email VARCHAR(15),
    @Password VARCHAR(15),
    @CustomerStatus VARCHAR(10),
    @CustomerAddress VARCHAR(50)
AS
BEGIN
    UPDATE customer
    SET FirstNAME = @FirstName,
        LastNAME = @LastName,
        contact = @Contact,
        E_MAIL = @Email,
        PASSWORD = @Password,
        CUSTOMER_STATUS = @CustomerStatus,
        CUSTOMER_ADDRESS = @CustomerAddress
    WHERE ID = @CustomerID
END;

--3 
CREATE PROCEDURE DeleteCustomer
    @CustomerID INT
AS
BEGIN
    DELETE FROM customer
    WHERE ID = @CustomerID
END;


-- INSERT AND UPDATE AND DELETE ====>>>> MENU TYPE TABLE 
--1
CREATE PROCEDURE InsertMenuType
    @TypeName VARCHAR(20)
AS
BEGIN
    INSERT INTO menutype (TYPES_NAME)
    VALUES (@TypeName)
END;

--2
CREATE PROCEDURE UpdateMenuType
    @MenuTypeID INT,
    @TypeName VARCHAR(20)
AS
BEGIN
    UPDATE menutype
    SET TYPES_NAME = @TypeName
    WHERE ID = @MenuTypeID
END;

--3 

CREATE PROCEDURE DeleteMenuType
    @MenuTypeID INT
AS
BEGIN
    DELETE FROM menutype
    WHERE ID = @MenuTypeID
END;



-- INSERT AND UPDATE AND DELETE ====>>>>MENU TABLE 
--1
CREATE PROCEDURE InsertMenu
    @ItemName VARCHAR(15),
    @ItemStatus VARCHAR(3),
    @Price INT,
    @MenuType INT
AS
BEGIN
    INSERT INTO menu (ITEM_NAME, ITEM_STATUS, PRICE, c)
    VALUES (@ItemName, @ItemStatus, @Price, @MenuType)
END;


--2
CREATE PROCEDURE UpdateMenu
    @MenuID INT,
    @ItemName VARCHAR(15),
    @ItemStatus VARCHAR(3),
    @Price INT,
    @MenuType INT
AS
BEGIN
    UPDATE menu
    SET ITEM_NAME = @ItemName,
        ITEM_STATUS = @ItemStatus,
        PRICE = @Price,
        MENU_TYPE = @MenuType
    WHERE ID = @MenuID
END;

--3 

CREATE PROCEDURE DeleteMenu
    @MenuID INT
AS
BEGIN
    DELETE FROM menu
    WHERE ID = @MenuID
END;

-- INSERT AND UPDATE AND DELETE ====>>>> DEAL OF THE DAY TABLE 
--1
CREATE PROCEDURE InsertDealOfTheDay
    @DealID INT,
    @DealName VARCHAR(30),
    @DealStatus VARCHAR(3),
    @Price INT,
    @MenuType INT
AS
BEGIN
    INSERT INTO deal_of_the_day (DEAL_ID, DEAL_NAME, DEAL_STATUS, PRICE, MENU_TYPE)
    VALUES (@DealID, @DealName, @DealStatus, @Price, @MenuType)
END;

--2
CREATE PROCEDURE UpdateDealOfTheDay
    @DealID INT,
    @DealName VARCHAR(30),
    @DealStatus VARCHAR(3),
    @Price INT,
    @MenuType INT
AS
BEGIN
    UPDATE deal_of_the_day
    SET DEAL_NAME = @DealName,
        DEAL_STATUS = @DealStatus,
        PRICE = @Price,
        MENU_TYPE = @MenuType
    WHERE DEAL_ID = @DealID
END;

--3 
CREATE PROCEDURE DeleteDealOfTheDay
    @DealID INT
AS
BEGIN
    DELETE FROM deal_of_the_day
    WHERE DEAL_ID = @DealID
END;


-- INSERT AND UPDATE AND DELETE ====>>>> ORDER TABLE 
--1
CREATE PROCEDURE InsertOrder
    @CustomerID INT,
    @UserID INT,
    @OrderStatus VARCHAR(4),
    @Amount INT,
    @OrderDate DATE
AS
BEGIN
    INSERT INTO orders (CUSTOMER_ID, USERs_ID, ORDER_STATUS, AMOUNT, ORDER_DATE)
    VALUES (@CustomerID, @UserID, @OrderStatus, @Amount, @OrderDate)
END;


--2
CREATE PROCEDURE UpdateOrder
    @OrderID INT,
    @CustomerID INT,
    @UserID INT,
    @OrderStatus VARCHAR(4),
    @Amount INT,
    @OrderDate DATE
AS
BEGIN
    UPDATE orders
    SET CUSTOMER_ID = @CustomerID,
        USERs_ID = @UserID,
        ORDER_STATUS = @OrderStatus,
        AMOUNT = @Amount,
        ORDER_DATE = @OrderDate
    WHERE ID = @OrderID
END;

--3 
CREATE PROCEDURE DeleteOrders
    @OrderID INT
AS
BEGIN
    DELETE FROM orders
    WHERE ID = @OrderID
END;


-- INSERT AND UPDATE AND DELETE ====>>>> ORDER DETAIL TABLE 
--1
CREATE PROCEDURE InsertOrderDetail
    @MenuID INT,
    @OrderID INT,
    @Quantity INT,
    @TotalAmount INT
AS
BEGIN
    INSERT INTO orderdetail (MENU_ID, ORDER_ID, QUANTITY, TOTAL_AMOUNT)
    VALUES (@MenuID, @OrderID, @Quantity, @TotalAmount)
END;

--2
CREATE PROCEDURE UpdateOrderDetail
    @OrderDetailID INT,
    @MenuID INT,
    @OrderID INT,
    @Quantity INT,
    @TotalAmount INT
AS
BEGIN
    UPDATE orderdetail
    SET MENU_ID = @MenuID,
        ORDER_ID = @OrderID,
        QUANTITY = @Quantity,
        TOTAL_AMOUNT = @TotalAmount
    WHERE ID = @OrderDetailID
END;

--3 

CREATE PROCEDURE DeleteOrderDetail
    @OrderDetailID INT
AS
BEGIN
    DELETE FROM orderdetail
    WHERE ID = @OrderDetailID
END;


-- INSERT AND UPDATE AND DELETE ====>>>> PAYMENT TABLE 
--1
CREATE PROCEDURE InsertPayment
    @OrderID INT,
    @UserID INT,
    @PaymentMethod VARCHAR(20),
    @PaymentDate DATE
AS
BEGIN
    INSERT INTO payment (ORDER_ID, USERs_ID, PAYMENT_METHOD, PAYMENT_DATE)
    VALUES (@OrderID, @UserID, @PaymentMethod, @PaymentDate)
END;


--2
CREATE PROCEDURE UpdatePayment
    @PaymentID INT,
    @OrderID INT,
    @UserID INT,
    @PaymentMethod VARCHAR(20),
    @PaymentDate DATE
AS
BEGIN
    UPDATE payment
    SET ORDER_ID = @OrderID,
        USERs_ID = @UserID,
        PAYMENT_METHOD = @PaymentMethod,
        PAYMENT_DATE = @PaymentDate
    WHERE ID = @PaymentID
END;

--3 
CREATE PROCEDURE DeletePayment
    @PaymentID INT
AS
BEGIN
    DELETE FROM payment
    WHERE ID = @PaymentID
END;


-- INSERT AND UPDATE AND DELETE ====>>>> WISHLIST TABLE 
--1
CREATE PROCEDURE InsertWishlist
    @CustomerID INT,
    @MenuID INT
AS
BEGIN
    INSERT INTO wishlist (customer_id, manu_id)
    VALUES (@CustomerID, @MenuID)
END;

--2
CREATE PROCEDURE UpdateWishlist
    @CustomerID INT,
    @MenuID INT,
    @NewMenuID INT
AS
BEGIN
    UPDATE wishlist
    SET manu_id = @NewMenuID
    WHERE customer_id = @CustomerID AND manu_id = @MenuID
END;


--3 
CREATE PROCEDURE DeleteWishlist
    @CustomerID INT,
    @MenuID INT
AS
BEGIN
    DELETE FROM wishlist
    WHERE customer_id = @CustomerID AND manu_id = @MenuID
END;



--==============================27>>>>>>>>>>> TRIGGER QUIRES<<<<<<<<<<<<27=============================

-- INSERT AND UPDATE AND DELETE ====>>>> USERS TABLE 

--1
CREATE TRIGGER Users_InsertTrigger
ON users
AFTER INSERT
AS
BEGIN
    -- Perform desired actions after insert
    -- You can access the inserted data using the "inserted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Users', 'Insert')
END;

--2 

CREATE TRIGGER Users_UpdateTrigger
ON users
AFTER UPDATE
AS
BEGIN
    -- Perform desired actions after update
    -- You can access the updated data using the "inserted" and "deleted" tables
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Users', 'Update')
END;


--3
CREATE TRIGGER Users_DeleteTrigger
ON users
AFTER DELETE
AS
BEGIN
    -- Perform desired actions after delete
    -- You can access the deleted data using the "deleted" table
    -- Example:
    INSERT INTO AuditLog (TableName, Action) VALUES ('Users', 'Delete')
END;


-- INSERT AND UPDATE AND DELETE ====>>>>  customer TABLE 
--1

CREATE TRIGGER Customer_InsertTrigger
ON customer
AFTER INSERT
AS
BEGIN
    -- Perform desired actions after insert
    -- You can access the inserted data using the "inserted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Customer', 'Insert')
END;


--2
CREATE TRIGGER Customer_UpdateTrigger
ON customer
AFTER UPDATE
AS
BEGIN
    -- Perform desired actions after update
    -- You can access the updated data using the "inserted" and "deleted" tables
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Customer', 'Update')
END;

--3
CREATE TRIGGER Customer_DeleteTrigger
ON customer
AFTER DELETE
AS
BEGIN
    -- Perform desired actions after delete
    -- You can access the deleted data using the "deleted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Customer', 'Delete')
END;

-- INSERT AND UPDATE AND DELETE ====>>>> menutype  TABLE 
--1
CREATE TRIGGER MenuType_InsertTrigger
ON menutype
AFTER INSERT
AS
BEGIN
    -- Perform desired actions after insert
    -- You can access the inserted data using the "inserted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('MenuType', 'Insert')
END;


--2
CREATE TRIGGER MenuType_UpdateTrigger
ON menutype
AFTER UPDATE
AS
BEGIN
    -- Perform desired actions after update
    -- You can access the updated data using the "inserted" and "deleted" tables
    -- Example:
    INSERT INTO AuditLog (TableName, Action) VALUES ('MenuType', 'Update')
END;

--3
CREATE TRIGGER MenuType_DeleteTrigger
ON menutype
AFTER DELETE
AS
BEGIN
    -- Perform desired actions after delete
    -- You can access the deleted data using the "deleted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('MenuType', 'Delete')
END;

-- INSERT AND UPDATE AND DELETE ====>>>> menu TABLE 
--1
CREATE TRIGGER Menu_InsertTrigger
ON menu
AFTER INSERT
AS
BEGIN
    -- Perform desired actions after insert
    -- You can access the inserted data using the "inserted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Menu', 'Insert')
END;


--2
CREATE TRIGGER Menu_UpdateTrigger
ON menu
AFTER UPDATE
AS
BEGIN
    -- Perform desired actions after update
    -- You can access the updated data using the "inserted" and "deleted" tables
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Menu', 'Update')
END;

--3


CREATE TRIGGER Menu_DeleteTrigger
ON menu
AFTER DELETE
AS
BEGIN
    -- Perform desired actions after delete
    -- You can access the deleted data using the "deleted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Menu', 'Delete')
END;

-- INSERT AND UPDATE AND DELETE ====>>>> order TABLE 
--1
CREATE TRIGGER Orders_InsertTrigger
ON orders
AFTER INSERT
AS
BEGIN
    -- Perform desired actions after insert
    -- You can access the inserted data using the "inserted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Orders', 'Insert')
END;

--2
CREATE TRIGGER Orders_UpdateTrigger
ON orders
AFTER UPDATE
AS
BEGIN
    -- Perform desired actions after update
    -- You can access the updated data using the "inserted" and "deleted" tables
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Orders', 'Update')
END;

--3
CREATE TRIGGER Orders_DeleteTrigger
ON orders
AFTER DELETE
AS
BEGIN
    -- Perform desired actions after delete
    -- You can access the deleted data using the "deleted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Orders', 'Delete')
END;


-- INSERT AND UPDATE AND DELETE ====>>>> deal of the day  TABLE 

--1 
CREATE TRIGGER DealOfTheDay_InsertTrigger
ON deal_of_the_day
AFTER INSERT
AS
BEGIN
    -- Perform desired actions after insert
    -- You can access the inserted data using the "inserted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('DealOfTheDay', 'Insert')
END;


-- 2
CREATE TRIGGER DealOfTheDay_UpdateTrigger
ON deal_of_the_day
AFTER UPDATE
AS
BEGIN
    -- Perform desired actions after update
    -- You can access the updated data using the "inserted" and "deleted" tables
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('DealOfTheDay', 'Update')
END;


--3 
CREATE TRIGGER DealOfTheDay_DeleteTrigger
ON deal_of_the_day
AFTER DELETE
AS
BEGIN
    -- Perform desired actions after delete
    -- You can access the deleted data using the "deleted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('DealOfTheDay', 'Delete')
END;

-- INSERT AND UPDATE AND DELETE ====>>>> order detail TABLE 
--1
CREATE TRIGGER OrderDetail_InsertTrigger
ON orderdetail
AFTER INSERT
AS
BEGIN
    -- Perform desired actions after insert
    -- You can access the inserted data using the "inserted" table
    -- Example:
   INSERT INTO AuditLog (TableName, Action) VALUES ('OrderDetail', 'Insert')
END;

--2
CREATE TRIGGER OrderDetail_UpdateTrigger
ON orderdetail
AFTER UPDATE
AS
BEGIN
    -- Perform desired actions after update
    -- You can access the updated data using the "inserted" and "deleted" tables
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('OrderDetail', 'Update')
END;

--3
CREATE TRIGGER OrderDetail_DeleteTrigger
ON orderdetail
AFTER DELETE
AS
BEGIN
    -- Perform desired actions after delete
    -- You can access the deleted data using the "deleted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('OrderDetail', 'Delete')
END;

-- INSERT AND UPDATE AND DELETE ====>>>> payment TABLE 
--1

CREATE TRIGGER Payment_InsertTrigger
ON payment
AFTER INSERT
AS
BEGIN
    -- Perform desired actions after insert
    -- You can access the inserted data using the "inserted" table
    -- Example:
    INSERT INTO AuditLog (TableName, Action) VALUES ('Payment', 'Insert')
END;


--2
CREATE TRIGGER Payment_UpdateTrigger
ON payment
AFTER UPDATE
AS
BEGIN
    -- Perform desired actions after update
    -- You can access the updated data using the "inserted" and "deleted" tables
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Payment', 'Update')
END;

--3
CREATE TRIGGER Payment_DeleteTrigger
ON payment
AFTER DELETE
AS
BEGIN
    -- Perform desired actions after delete
    -- You can access the deleted data using the "deleted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Payment', 'Delete')
END;

-- INSERT AND UPDATE AND DELETE ====>>>> wish list TABLE 
--1
CREATE TRIGGER Wishlist_InsertTrigger
ON wishlist
AFTER INSERT
AS
BEGIN
    -- Perform desired actions after insert
    -- You can access the inserted data using the "inserted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Wishlist', 'Insert')
END;

--2
CREATE TRIGGER Wishlist_UpdateTrigger
ON wishlist
AFTER UPDATE
AS
BEGIN
    -- Perform desired actions after update
    -- You can access the updated data using the "inserted" and "deleted" tables
    -- Example:
    INSERT INTO AuditLog (TableName, Action) VALUES ('Wishlist', 'Update')
END;

--3

CREATE TRIGGER Wishlist_DeleteTrigger
ON wishlist
AFTER DELETE
AS
BEGIN
    -- Perform desired actions after delete
    -- You can access the deleted data using the "deleted" table
    -- Example:
     INSERT INTO AuditLog (TableName, Action) VALUES ('Wishlist', 'Delete')
END;



--==============================9>>>>>>>>>>> TRANSACTION QUIRES<<<<<<<<<<<<9=============================


-- user 
BEGIN TRANSACTION

BEGIN TRY
    INSERT INTO users (FullNAME, contact, E_MAIL, PASSWORD)
    VALUES ('sufyan', 030000000, 'OO@gamil.com', 99999999);

   Print 'Transaction Successfully Done!';

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
    Print 'Transaction Filed';
END CATCH

-- customer
BEGIN TRANSACTION

BEGIN TRY
    INSERT INTO customer (FirstNAME, LastNAME, contact, E_MAIL, PASSWORD, CUSTOMER_STATUS, CUSTOMER_ADDRESS)
    VALUES ('Jane', 'Doe', '987654321', 'jane@example.com', 'password', 'YES', '123 Main St');

     Print 'Transaction Successfully Done!';e

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
     Print 'Transaction Filed';
END CATCH

-- menu type 
BEGIN TRANSACTION

BEGIN TRY
    INSERT INTO menutype (TYPES_NAME)
    VALUES ('Beverages');

     Print 'Transaction Successfully Done!';

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
   Print 'Transaction Filed';
END CATCH

-- menu
BEGIN TRANSACTION

BEGIN TRY
    INSERT INTO menu (ITEM_NAME, ITEM_STATUS, PRICE, MENU_TYPE)
    VALUES ('Burger', 'YES', 10, 1);

     Print 'Transaction Successfully Done!';

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
    Print 'Transaction Filed';
END CATCH

-- deal of the day 
BEGIN TRANSACTION

BEGIN TRY
    INSERT INTO deal_of_the_day (DEAL_ID, DEAL_NAME, DEAL_STATUS, PRICE, MENU_TYPE)
    VALUES (1, 'Special Deal', 'YES', 19.99, 1);

     Print 'Transaction Successfully Done!';

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
     Print 'Transaction Filed';
END CATCH

-- order 
BEGIN TRANSACTION

BEGIN TRY
    INSERT INTO orders (CUSTOMER_ID, USERs_ID, ORDER_STATUS, AMOUNT, ORDER_DATE)
    VALUES (1, 1, 'DONE', 100, GETDATE());

     Print 'Transaction Successfully Done!';

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
     Print 'Transaction Filed';
END CATCH

-- order detail
BEGIN TRANSACTION

BEGIN TRY
    INSERT INTO orderdetail (MENU_ID, ORDER_ID, QUANTITY, TOTAL_AMOUNT)
    VALUES (1, 1, 2, 20);

     Print 'Transaction Successfully Done!';

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
     Print 'Transaction Filed';
END CATCH

-- payment 
BEGIN TRANSACTION

BEGIN TRY
    INSERT INTO payment (ORDER_ID, USERs_ID, PAYMENT_METHOD, PAYMENT_DATE)
    VALUES (1, 1, 'Credit Card', GETDATE());

     Print 'Transaction Successfully Done!';

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
     Print 'Transaction Filed';
END CATCH

-- wishlist

BEGIN TRANSACTION

BEGIN TRY
    INSERT INTO wishlist (customer_id, manu_id)
    VALUES (1, 1);

    Print 'Transaction Successfully Done!';

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION
    Print 'Transaction Filed';
	end catch


